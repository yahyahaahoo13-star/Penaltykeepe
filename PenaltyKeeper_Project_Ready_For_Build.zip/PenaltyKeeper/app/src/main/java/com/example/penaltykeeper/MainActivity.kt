package com.example.penaltykeeper

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var score = 0
    private var busy = false
    private lateinit var scoreText: TextView
    private lateinit var message: TextView
    private lateinit var keeper: TextView
    private lateinit var ball: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildGame()
    }

    private fun buildGame() {
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(20, 35, 25))
        }

        val title = TextView(this).apply {
            text = "⚽ PENALTY KEEPER"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        scoreText = TextView(this).apply {
            text = "الأهداف: 0"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val field = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(76, 150, 70))
        }

        val goal = TextView(this).apply {
            text = "🥅"
            textSize = 100f
            gravity = Gravity.CENTER
        }
        field.addView(goal, FrameLayout.LayoutParams(-1, 260).apply {
            gravity = Gravity.TOP
        })

        keeper = TextView(this).apply {
            text = "🧤🧍"
            textSize = 48f
            gravity = Gravity.CENTER
        }
        field.addView(keeper, FrameLayout.LayoutParams(-2, 100).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = 105
        })

        ball = TextView(this).apply {
            text = "⚽"
            textSize = 42f
            gravity = Gravity.CENTER
        }
        field.addView(ball, FrameLayout.LayoutParams(-2, 80).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = 25
        })

        message = TextView(this).apply {
            text = ""
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val buttons = LinearLayout(this).apply {
            gravity = Gravity.CENTER
        }
        fun addShot(label: String, target: Float) {
            val b = Button(this).apply {
                text = label
                setOnClickListener { shoot(target) }
            }
            buttons.addView(b, LinearLayout.LayoutParams(0, 70, 1f).apply {
                setMargins(5, 5, 5, 5)
            })
        }
        addShot("⬅️ يسار", 0.18f)
        addShot("⬆️ وسط", 0.50f)
        addShot("➡️ يمين", 0.82f)

        val reset = Button(this).apply {
            text = "إعادة اللعب"
            setOnClickListener {
                score = 0
                busy = false
                scoreText.text = "الأهداف: 0"
                message.text = ""
            }
        }

        main.addView(title, LinearLayout.LayoutParams(-1, 70))
        main.addView(scoreText, LinearLayout.LayoutParams(-1, 60))
        main.addView(field, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(message, LinearLayout.LayoutParams(-1, 55))
        main.addView(buttons, LinearLayout.LayoutParams(-1, 80))
        main.addView(reset, LinearLayout.LayoutParams(-1, 65))
        setContentView(main)
    }

    private fun shoot(target: Float) {
        if (busy) return
        busy = true
        val saved = Math.random() < 0.35
        message.text = "..."
        ball.animate().translationX((target - 0.5f) * 500f).translationY(-500f).setDuration(550)
            .withEndAction {
                if (saved) {
                    message.text = "🧤 الحارس صدّها!"
                } else {
                    score++
                    scoreText.text = "الأهداف: $score"
                    message.text = "⚽ هدف!"
                }
                ball.animate().translationX(0f).translationY(0f).setDuration(350)
                    .withEndAction {
                        message.text = ""
                        busy = false
                    }.start()
            }.start()
    }
}
